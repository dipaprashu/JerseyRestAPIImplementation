package com.it.repository;

import com.it.model.User;

public interface UserDao {

	public User findById(int id);
	public User findBySSO(String sso);
}