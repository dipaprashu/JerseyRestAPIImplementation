package com.it.repository;


import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;

import com.it.model.Pet;

@Component
public interface PetsRepository extends MongoRepository<Pet,String> {

	public Pet findBy_id(ObjectId id);
	
}
