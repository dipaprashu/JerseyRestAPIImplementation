package com.it.resource;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

@Path("res")
public class MyResource {

	@GET
	@Produces("application/json")
	@Consumes("application/json")
	public Response getAllEployees()
	{
	    Employees list = new Employees();
	    list.setEmployeeList(new ArrayList<Employee>());
	    list.getEmployeeList().add(new Employee(1, "Lokesh Gupta"));
	    list.getEmployeeList().add(new Employee(2, "Alex Kolenchiskey"));
	    list.getEmployeeList().add(new Employee(3, "David Kameron"));
	     System.out.println("List of employees--->"+list);
	     List<Employee> empList=list.getEmployeeList();
	     for(Employee emp:empList) {
	    	 System.out.println("Employee ID"+emp.getId());
	    	 System.out.println("Employee Name"+emp.getName());
	     }
	    return Response.ok().entity(list).cookie(new NewCookie("cookieResponse", "cookieValueInReturn")).build();
	}
	
}//class
