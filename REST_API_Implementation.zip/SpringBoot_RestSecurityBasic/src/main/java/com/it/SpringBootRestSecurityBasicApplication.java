package com.it;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.it.controller","com.it.dao"})
public class SpringBootRestSecurityBasicApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(SpringBootRestSecurityBasicApplication.class, args);
		
	}//main
	
}//class
