package com.it;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.it.service","com.it.controller"})
public class SpringBootRestApiExpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApiExpApplication.class, args);
	}
}
