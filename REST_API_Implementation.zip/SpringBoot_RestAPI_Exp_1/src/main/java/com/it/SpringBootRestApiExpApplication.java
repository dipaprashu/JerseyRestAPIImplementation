package com.it;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.it.filter.CORSFilter;

//,exclude = {SecurityAutoConfiguration.class}
@SpringBootApplication//(scanBasePackages= {"com.it.service","com.it.controller","com.it.config","com.it.filter"})
public class SpringBootRestApiExpApplication {

	@Autowired(required=true)
	@Qualifier(value="corsFilter")
	private CORSFilter filter;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApiExpApplication.class, args);
	}
	
	/**
	 * to register corsFilter to Initializer
	 * 
	 * @author Sudhanhsu
	 * @return FilterRegistrationBean
	 */
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public FilterRegistrationBean filterRegistrationBean() {
		FilterRegistrationBean bean = new FilterRegistrationBean(filter);
		bean.addUrlPatterns("/*");
		return bean;
	}
	
}//class