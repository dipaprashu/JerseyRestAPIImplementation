package com.it.context;


import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.stereotype.Component;

@Component
public class CustomContainer2 implements WebServerFactoryCustomizer<TomcatServletWebServerFactory>{
	
	@Override
	public void customize(TomcatServletWebServerFactory factory) {
		
	}

}//class
