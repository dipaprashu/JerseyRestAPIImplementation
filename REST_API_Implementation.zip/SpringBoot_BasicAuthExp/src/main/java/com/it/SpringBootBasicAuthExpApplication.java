package com.it;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.it.controller"})
public class SpringBootBasicAuthExpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBasicAuthExpApplication.class, args);
	}
}
