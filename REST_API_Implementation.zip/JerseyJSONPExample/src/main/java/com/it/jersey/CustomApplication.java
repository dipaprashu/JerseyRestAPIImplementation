package com.it.jersey;

import javax.json.stream.JsonGenerator;

import org.glassfish.jersey.jsonp.JsonProcessingFeature;
import org.glassfish.jersey.server.ResourceConfig;

public class CustomApplication extends ResourceConfig {
	
	 public CustomApplication()
	    {
	        register(JsonProcessingFeature.class);
	        packages("com.it.jersey");
	        packages("org.glassfish.jersey.examples.jsonp");
	       // register(LoggingFilter.class);
	        property(JsonGenerator.PRETTY_PRINTING, true);
	    }

}//class
